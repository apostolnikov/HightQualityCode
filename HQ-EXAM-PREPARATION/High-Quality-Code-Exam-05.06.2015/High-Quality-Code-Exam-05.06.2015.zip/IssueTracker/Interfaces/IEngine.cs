﻿namespace IssueTracker.Interfaces
{
    using System;

    public interface IEngine
    {
        void Run();
    }
}
